const { request } = require('../utils/request');
//小说接口
const baseURL = 'https://mobile.ximalaya.com/mobile/discovery/v3/recommend/hotAndGuess?code=43_310000_3100&device=android&version=5.4.45';
function getData() {
  return request({baseURL})
}

module.exports = {
  getData
}