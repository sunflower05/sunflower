Page({

	/**
	 * 页面的初始数据
	 */
	data: {
		
	},

	/**
	 * 生命周期函数--监听页面加载
	 */


	onLoad: function (options) {
		this.setData({
			// 带参 url 和title到这里
			performanceInfo: [{
				imgurl: options.url + '=5&upload_type=album&device_type=ios&name=medium&magick=png',
				title: options.title,
				author: "某某某",
				num1: "767.6万",
				num2: "257"
			}],
			imgurl: options.url + '=5&upload_type=album&device_type=ios&name=medium&magick=png',
			performance:[{
				name: options.title,
				year: "2年前",
				count: "5601.9万",
				time: "34:36"
			},{
				name: options.title,
				year: "2年前",
				count: "5601.9万",
				time: "34:36"
			},{
				name: options.title,
				year: "2年前",
				count: "5601.9万",
				time: "34:36"
			},]
		});

	
	}
})