//index.js
//获取应用实例
const app = getApp()
const myRequest = require('../../api/index.js');
Page({
	/**
	 * 页面的初始数据
	 */
	data: {
		imgList: [
			'/image/swiper/ad1.jpg',
			'/image/swiper/ad2.jpg',
			'/image/swiper/ad3.jpg',
			'/image/swiper/ad4.jpg',
			'/image/swiper/ad5.jpg',
			'/image/swiper/ad6.jpg',
			'/image/swiper/ad7.jpg'
		],
		navList: [{
			icon: '/image/nav-icon/rank.svg',
			events: 'goToBangDan',
			text: '榜单'
		},
		{
			icon: '/image/nav-icon/book.svg',
			events: 'goToBangDan',
			text: '听小说'
		},
		{
			icon: '/image/nav-icon/radio.svg',
			events: 'goToBangDan',
			text: '情感电台'
		},
		{
			icon: '/image/nav-icon/knowledge.svg',
			events: 'goToBangDan',
			text: '听知识'
		},
		],
		swiperCurrent: 0,
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {
		//初始化时加载
		const that = this
		myRequest.getData().then(res => {
			// console.log(res),
			that.setData({
				//如果网络请求成功才显示,否则显示网络丢失
				showitem: true,
				guess: res.data.guess.list.slice(0, 3),
				xiaoshuocontent: res.data.hotRecommends.list[0].list,
				newscontent:res.data.hotRecommends.list[1].list,
				xiangshengcontent: res.data.hotRecommends.list[2].list,
				tuokocontent: res.data.hotRecommends.list[4].list,
				streamcontent:res.data.zhubo_live.list,
				historycontent:res.data.hotRecommends.list[3].list,
				peoplecontent:res.data.hotRecommends.list[5].list,
				musiccontent:res.data.hotRecommends.list[6].list,
				entertainmentcontent:res.data.hotRecommends.list[7].list,
				sentimentcontent:res.data.hotRecommends.list[8].list,
				englishcontent:res.data.hotRecommends.list[9].list,
				financecontent:res.data.hotRecommends.list[10].list,
				techcontent:res.data.hotRecommends.list[11].list,
				lovecontent:res.data.hotRecommends.list[12].list,
				stroycontent:res.data.hotRecommends.list[13].list,
				carcontent:res.data.hotRecommends.list[14].list,
			})
		}).catch(err => {
			that.setData({
				showitem: false
			})
		})
	},
	//轮播图改变事件
	swiperChange: function (e) {
		this.setData({
			swiperCurrent: e.detail.current
		})
	},
	goToBangDan: function () {
		wx.navigateTo({
			url: '/pages/index/bangdan/bangdan',
		})
	},
	gotoDetails(e) {
		const url = e.currentTarget.dataset.coverimg;
		const title = e.currentTarget.dataset.title;
		wx.navigateTo({
			// 页面传参
			url: '/pages/details/details?url=' + url + '&title=' + title,
		})
	}
})