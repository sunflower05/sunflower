// 引用express和fs这两个包
const express = require('express');
const fs = require('fs');

// 定义app
const app = express();

// 接口
app.get('/contact', (req, res)=>{
	fs.readFile('./data.json', (err, data)=>{
		if(err) throw err;
		res.send(data);
	});
});


// 监听端口号
app.listen(3000, ()=>{
	console.log("Sever is running at http://localhost:3000");
});