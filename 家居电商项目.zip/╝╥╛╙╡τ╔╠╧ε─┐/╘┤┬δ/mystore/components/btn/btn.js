// components/btn/btn.js
Page({
  data: {

  },

  // 返回顶部的触发事件
  toTopFn(){
    this.triggerEvent('totop', 0);
  },

  // 拨打电话
  callFn(){
    wx.makePhoneCall({
      phoneNumber: '020-85628002'
    })
  },

  // 跳转到地图页面
  jumpToMap(){
    wx.navigateTo({
      url: '/pages/map/map'
    })
  }
})