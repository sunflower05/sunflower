// pages/contact/contact.js
Page({
  data: {
    address: "",
    postal: "",
    hotline: "",
    workday: "",
    email: ""
  },
  onLoad(){
    let _this = this;
    wx.request({
      url: 'http://localhost:3000/contact',
      method: "get",
      success(res){
        _this.setData({
          address: res.data.address,
          postal: res.data.postal,
          hotline: res.data.hotline,
          workday: res.data.workday,
          email: res.data.email
        });
      },
      fail(err){
        console.log(err);
      }
    })
  }

})