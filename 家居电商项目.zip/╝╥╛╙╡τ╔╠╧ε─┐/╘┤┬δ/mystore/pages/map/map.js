// map.js
Page({
  data: {
    markers: [{
      id: 0,
      latitude: 23.138169,
      longitude: 113.384241,
      width: 50,
      height: 50
    }]
  }
})